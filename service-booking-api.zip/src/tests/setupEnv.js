// src/tests/jest.setup.js
require('dotenv').config({ path: '.env.test' });
